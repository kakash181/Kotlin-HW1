package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private var ed_name: EditText? = null
    private var tv_text : TextView? = null
    private var tv_name: TextView? = null
    private var tv_winner: TextView? = null
    private var tv_mmora: TextView? = null
    private var tv_cmora: TextView? = null
    private var btn_scissor: RadioButton? = null
    private var btn_stone: RadioButton? = null
    private var btn_paper: RadioButton? = null
    private var btn_mora: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        ed_name = findViewById(R.id.ed_name)
        tv_text = findViewById(R.id.tv_text)
        tv_name = findViewById(R.id.tv_name)
        tv_winner = findViewById(R.id.tv_winner)
        tv_mmora = findViewById(R.id.tv_mmora)
        tv_cmora = findViewById(R.id.tv_cmora)
        btn_scissor = findViewById(R.id.btn_scissor)
        btn_stone = findViewById(R.id.btn_stone)
        btn_paper = findViewById(R.id.btn_paper)
        btn_mora = findViewById(R.id.btn_mora)
        val ed_name = ed_name ?: return
        val tv_text = tv_text ?: return
        val tv_name = tv_name ?: return
        val tv_winner = tv_winner ?: return
        val tv_mmora = tv_mmora ?: return
        val tv_cmora = tv_cmora ?: return
        val btn_scissor = btn_scissor ?: return
        val btn_stone = btn_stone ?: return
        val btn_paper = btn_paper ?: return
        val btn_mora = btn_mora ?: return
        btn_mora.setOnClickListener(View.OnClickListener { v: View? ->
            if (ed_name.length() < 1) tv_text.setText("請輸入玩家姓名") else {
                tv_name.setText(String.format("名字\n%s", ed_name.getText().toString()))
                if (btn_scissor.isChecked()) tv_mmora.setText("我方出拳\n剪刀") else if (btn_stone.isChecked()) tv_mmora.setText(
                    "我方出拳\n石頭"
                ) else tv_mmora.setText("我方出拳\n布")
                val computer = (Math.random() * 3).toInt()
                if (computer == 0) tv_cmora.setText("電腦出拳\n剪刀") else if (computer == 1) tv_cmora.setText(
                    "電腦出拳\n石頭"
                ) else tv_cmora.setText("電腦出拳\n布")
                if (btn_scissor.isChecked() && computer == 2 || btn_stone.isChecked() && computer == 0 ||
                    btn_paper.isChecked() && computer == 1
                ) {
                    tv_winner.setText(String.format("勝利者\n%s", ed_name.getText()))
                    tv_text.setText("恭喜你獲勝了！！！")
                } else if (btn_scissor.isChecked() && computer == 1 || btn_stone.isChecked() && computer == 2 ||
                    btn_paper.isChecked() && computer == 0
                ) {
                    tv_winner.setText("勝利者\n電腦")
                    tv_text.setText("可惜，電腦獲勝了！")
                } else {
                    tv_winner.setText("勝利者\n平手")
                    tv_text.setText("平局，請再試一次！")
                }
            }
        })
    }
}